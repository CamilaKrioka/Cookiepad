const express = require('express');
const router = express.Router();


const recetas = [
    {
        id:1,
        nombre:"Bocaditos de calabaza",
        imagen: process.env.IMAGES_URL + "bocaditos_de_calabaza.jpg",
        usuario:"Pepe",
        imagenUsuario: process.env.IMAGES_URL + "pepe.png",

    },
    {
        id:2,
        nombre:"Nachos de pollo sin harina",
        imagen: process.env.IMAGES_URL + "nachos.jpg",
        usuario:"Maria",
        imagenUsuario: process.env.IMAGES_URL + "maria.png",

    },
    {
        id:3,
        nombre:"Pionono",
        imagen: process.env.IMAGES_URL + "pionono.jpg",
        usuario:"Pepe",
        imagenUsuario: process.env.IMAGES_URL + "pepe.png",

    },
    {
        id:4,
        nombre:"Galletitas de zanahoria y nueces",
        imagen: process.env.IMAGES_URL + "galletitas_de_zanahoria.jpg",
        usuario:"Maria",
        imagenUsuario: process.env.IMAGES_URL + "maria.png",

    },
    {
      
        id:5,
        nombre:"Bizcochuelo de naranja",
        imagen: process.env.IMAGES_URL + "bizcochuelo.jpg",
        usuario:"Pepe",
        imagenUsuario: process.env.IMAGES_URL + "pepe.png",

    },
    {
        id:6,
        nombre:"Pastas Mediterráneas",
        imagen: process.env.IMAGES_URL + "pastas_mediterraneas.jpg",
        usuario:"Maria",
        imagenUsuario: process.env.IMAGES_URL + "maria.png",

    }







]

router.get('/', (req, res) => {
    res.json(recetas);
})

router.get('//:id', (req, res) => {
    
    let receta =  recetas.filter( receta => receta.id == req.params.id );
                    
    if (receta.length == 1){
        receta = receta[0];
    }

    res.json(receta);

})

module.exports = router;