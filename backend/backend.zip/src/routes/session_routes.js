const express = require('express');
const router = express.Router();

router.post('/', (req, res) =>{

    if( req.body.user === 'pepe' && req.body.password === '123456' ){
        req.session.user = 'pepe';

        res.json(
            {
                status : 'ok',
                message : 'sesion iniciada',
                loggedUser: {
                     
                                id: 125,
                                nombre: 'Pepe Garcia'
                             }
                    
             }
         )

    }
    else{
        res.json(
            {
              
                    status:'error',
                    mesagge: 'usuario y/o contraseña no validos',
            }
                );
        }


})

router.delete('/', (req, res) =>{
    req.session.destroy( err =>{
        if( err ){
            res.json(
                {
                    status : 'error',
                    mesagge : 'Error al cerra la sesion'
                
                }
            )
        }else{
            res.clearCookie('cookiepad');
            res.json(
                {
                    status : 'ok',
                    message : 'sesion cerrada'
                }
            )
        }
    })
})

 module.exports = router;